﻿namespace XAppObject {
    public class XAppNoGeom3D : XAppObject3D {
        // constructor 
        public XAppNoGeom3D(string name) : base($"{ name }/NoGeom3D") {
        }

        protected override void addComponents() {
        }
    }
}