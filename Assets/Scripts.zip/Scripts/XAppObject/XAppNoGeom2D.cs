﻿namespace XAppObject {
    public class XAppNoGeom2D : XAppObject2D {
        // constructor 
        public XAppNoGeom2D(string name) : base($"{ name }/NoGeom2D") {
        }

        protected override void addComponents() {
        }
    }
}