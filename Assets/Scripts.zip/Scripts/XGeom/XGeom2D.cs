﻿namespace XGeom {
    public abstract class XGeom2D : XGeom {
    }
}