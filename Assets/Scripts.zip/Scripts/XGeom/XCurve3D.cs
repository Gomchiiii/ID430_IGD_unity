using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public abstract class XCurve3D : XGeom.XGeom3D
{
}
