﻿namespace XGeom {
    public abstract class XGeom3D : XGeom {
    }
}