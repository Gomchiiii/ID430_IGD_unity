namespace X {
    public interface XExecutable {
        bool execute();
    }
}