using XAppObject;

namespace X {
    public class XScreen : XAppNoGeom2D {
        // constructor
        public XScreen() : base("Screen") {
        }
    }
}